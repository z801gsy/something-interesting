﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfService1
{
    // 注意: 使用“重构”菜单上的“重命名”命令，可以同时更改代码和配置文件中的接口名“IServiceDual”。
    [ServiceContract(Namespace = "WcfExamples",
        SessionMode = SessionMode.Required,
        CallbackContract = typeof(IStudentsDuplexCallback))]

    //在服务端实现该接口
    public interface IServiceDual
    {
        [OperationContract(IsOneWay = true)]
        void Login(string greeting);

        [OperationContract(IsOneWay = true)]
        void TalktoAll(string name,string msg);
    }

    //在客户端实现该接口
    public interface IStudentsDuplexCallback
    {
        [OperationContract(IsOneWay = true)]
        void Receive(string response);
    }
}
