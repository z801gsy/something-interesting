﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class CC
    {
        public static List<User> users = new List<User>();

        public static void SendToAll(string str)
        {
            foreach (User item in CC.users)
            {
                item.callback.Receive(str);
            }

        }
    }
}