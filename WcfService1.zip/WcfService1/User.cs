﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class User
    {
       public IStudentsDuplexCallback callback;
       public string username;

    }
}