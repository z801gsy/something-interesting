﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfService1
{
    // 注意: 使用“重构”菜单上的“重命名”命令，可以同时更改代码、svc 和配置文件中的类名“ServiceDual”。
    // 注意: 为了启动 WCF 测试客户端以测试此服务，请在解决方案资源管理器中选择 ServiceDual.svc 或 ServiceDual.svc.cs，然后开始调试。
    public class ServiceDual : IServiceDual
    {
        
        public void Login(string name)
        {
            OperationContext context = OperationContext.Current;
            IStudentsDuplexCallback callback = context.GetCallbackChannel<IStudentsDuplexCallback>();
            User user = new User();
            user.callback = callback;
            user.username = name;
            CC.users.Add(user);

            foreach (User item in CC.users)
            {
                item.callback.Receive(name);
            }

           // callback.Receive("Hello，" + name);
           // System.Threading.Thread.Sleep(1000);
          //  callback.Receive("你好，我是服务端。");

        }
        public void TalktoAll(string name, string msg)
        {
            CC.SendToAll(name + ":" + msg);

        }

    }
}
